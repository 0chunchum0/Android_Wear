package com.dossis.curso4semana4.restApi;

public class KeysFirebaseRestAPI {
    public static final String ROOT_URL = "https://nameless-sierra-76810.herokuapp.com/";
    public static final String KEY_POST_REGISTRAR_USUARIO ="registrar-usuario/";
    public static final String KEY_POST_SEND_LIKE="send-like/";
}
